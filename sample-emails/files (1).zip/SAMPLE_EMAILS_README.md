# Sample Emails for ScamShield Testing

This folder contains example emails for testing your phishing detection model.

## 📧 Files

### Phishing Emails (Should be detected as phishing)
- **phishing_email_1.txt** - Amazon account verification scam
  - Red flags: Urgency ("immediately"), suspicious sender domain (amaz0n), shortened links, threatening account suspension
  
- **phishing_email_2.txt** - PayPal payment method update scam
  - Red flags: Domain typosquatting (paypa1), urgency, fake link, prize offer bait

### Legitimate Emails (Should be detected as legitimate)
- **legitimate_email_1.txt** - GitHub security notification
  - Characteristics: Real service, informational, no urgency, no links to click
  
- **legitimate_email_2.txt** - Work team meeting reminder
  - Characteristics: Internal communication, no suspicious content, straightforward

---

## 🧪 How to Use for Testing

### Manual Testing
```python
from scamshield import detector

# Read a sample email
with open('phishing_email_1.txt', 'r') as f:
    content = f.read()

# Test prediction
result = detector.predict_email(
    subject="Urgent: Verify Your Account Immediately",
    body=content
)

print(f"Is phishing: {result['is_phishing']}")
print(f"Confidence: {result['phishing_probability']:.2%}")
```

### Batch Testing
```python
import os
from scamshield import detector

sample_dir = 'sample-emails/'
results = []

for filename in os.listdir(sample_dir):
    if filename.endswith('.txt'):
        with open(os.path.join(sample_dir, filename), 'r') as f:
            content = f.read()
        
        result = detector.predict_email(
            subject="Test Email",
            body=content
        )
        
        results.append({
            'file': filename,
            'is_phishing': result['is_phishing'],
            'confidence': result['phishing_probability']
        })

# Print results
for r in results:
    print(f"{r['file']}: {r['is_phishing']} ({r['confidence']:.2%})")
```

---

## 📊 Expected Results

When you run your trained model on these samples:

| Email | Type | Expected Result |
|-------|------|-----------------|
| phishing_email_1.txt | Phishing | ✅ Should detect as phishing (90%+) |
| phishing_email_2.txt | Phishing | ✅ Should detect as phishing (85%+) |
| legitimate_email_1.txt | Legitimate | ✅ Should detect as legitimate (90%+) |
| legitimate_email_2.txt | Legitimate | ✅ Should detect as legitimate (95%+) |

---

## 🎯 Adding Your Own Test Emails

To add more test emails:

1. Create a `.txt` file with the email content
2. Name it descriptively (e.g., `phishing_crypto_scam.txt`)
3. Add it to this folder
4. Test with your model
5. Update this README with results

### Email Format (Optional)
```
From: sender@domain.com
Subject: Email subject line

Email body text here...
```

Or just plain text - the model can handle both.

---

## ✨ Tips for Good Test Cases

### For Phishing Emails:
- Include urgency indicators ("urgent", "immediately", "act now")
- Use suspicious links or shortened URLs
- Include sender spoofing attempts
- Add capitalization and exclamation marks
- Request sensitive information (passwords, payment methods)

### For Legitimate Emails:
- Use real company domains
- Keep tone professional and calm
- Provide helpful, relevant information
- No requests for sensitive data
- Clear context and purpose

---

## 🔄 Updating Test Suite

As your model improves, update this folder:
1. Add emails that your model struggles with
2. Test edge cases (newsletters, promotional emails, etc.)
3. Include emails in different languages (future versions)
4. Add emails with attachments (test file extraction)

